**How to import ?**

import polishstring

**Methods Included**

inf_prf(st)-->converts infix equation to prefix

inf_pof(st)-->converts infix equation to postfix

pof_prf(st)-->converts postfix equation to prefix

pof_inf(st)-->converts postfix equation to infix

prf_pof(st)-->converts prefix equation to postfix

prf_inf(st)-->converts prefix equation to infix

**Remember**

It only supports one character as an operand
